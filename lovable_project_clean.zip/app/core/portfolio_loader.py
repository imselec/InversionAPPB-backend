def load_portfolio():
    return [
        {"ticker": "PG", "shares": 0.7, "sector": "Consumer"},
        {"ticker": "JNJ", "shares": 1.0, "sector": "Healthcare"},
        {"ticker": "AVGO", "shares": 0.5, "sector": "Technology"},
    ]
