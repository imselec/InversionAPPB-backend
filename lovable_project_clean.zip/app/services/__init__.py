# Archivo vacío, solo para que Python reconozca 'app' como paquete
