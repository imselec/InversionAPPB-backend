from .recommendation import (
    RecommendationRunSchema,
    RecommendationItemSchema,
)

__all__ = [
    "RecommendationRunSchema",
    "RecommendationItemSchema",
]  # Este archivo puede estar vacío
